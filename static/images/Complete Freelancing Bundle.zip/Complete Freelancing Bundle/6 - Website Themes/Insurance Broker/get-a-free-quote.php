<?php



if ($_POST["submit"]) {





      if (!$_POST['insurance-option']) {

     

      $error.="<br /> Please select the type of insurance you need";



     

     }

      

      

     if (!$_POST['name']) {



       $error="<br />Please enter your name";



     }

      

     if (!$_POST['email']) {



       $error.="<br />Please enter your email address";



     }

     

      

      if (!$_POST['phone']) {

     

      $error.="<br /> Please enter your phone number";

     

     }



     if (!$_POST['idnumber']) {

     

      $error.="<br /> Please enter your ID Number";

     

     }



      if (!$_POST['message']) {



       $error.="<br />Please enter a message";



     }

      

     if ($_POST['email']!="" AND !filter_var($_POST['email'],

FILTER_VALIDATE_EMAIL)) {

      

     $error.="<br />Please enter a valid email address";



     }

     

      

     if ($error) {



 $result='<div class="alert alert-danger"><strong>There were error(s)

in your form:</strong>'.$error.'</div>';



     } else {
      

 if (mail("info@youremail.com", "Request to get a quote from Insurance Broker", 
  /* ---- Email where you want to recieve the contact messages ---- */


"Name: ".$_POST['name']."

Phone: ".$_POST['phone']." 

Email: ".$_POST['email']."

Insurance Type: ".$_POST['insurance-option']."

ID Number: ".$_POST['idnumber']."

Message: ".$_POST['message'])) {

$result='<div class="alert alert-success"> <strong> Thank

you!</strong> We\'ll get back to you shortly.</div>';

} else {

$result='<div class="alert alert-danger">Sorry, there was

an error sending your message. Please try again later.</div>';

}

}

}

?>


<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta content="" name="description">
  <!-- Meta Description -->

              <title>Get a Free Quote</title>


        <!-- CSS Stylesheets -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/get-quote-style.css" />
  <link rel="stylesheet" type="text/css" href="css/navbar.css" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link href="css/testimonials-styling.css" rel="stylesheet" type="text/css">


      <!--Font Styles -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">

  <!--Favicon -->
  <link href="images/insurance-broker-favicon.jpg" rel="icon">

</head>

<body data-spy="scroll" data-target=".navbar-collapse">

  <div class="container-fluid" id="banner">

    <div class="top-banner">

    <div class="contacting-number">

          <p align="right" class="contactnumber">202-555-0122</p>

          <p align="right" class="top-quote"><a href="https://insurancebrokerwebsite.com/get-a-free-quote.php">GET A FREE QUOTE</a></p>  

      </div><!--contacting-number-->


      <div class="row" id="logo-top">

        <div align="center" class="col-md-6 col-md-offset-3">

          <a href="https://insurancebrokerwebsite.com">

            <img alt="insurance-broker-logo" class="img-responsive logo" src="images/insurance-broker-logo.png"></a>
              
              <p align="center" class="tagline">You Are Not Just A Number...</p>

        </div><!--end of col-md-6-->

      </div><!--end of logo-top-->

    </div><!--top-banner-->

  </div><!--end of banner-->

  <nav class="navbar navbar-default navbar-static-top" id="topnavbar" role="navigation">

    <div class="navbar-header">

      <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button">

        <span class="sr-only">Toggle navigation</span> 
          <span class="icon-bar"></span> 
          <span class="icon-bar"></span> 
           <span class="icon-bar"></span>

      </button>

    </div>

    <div align="center" class="collapse navbar-collapse">

          <ul class="nav navbar-nav">

              <li><a href="https://insurancebrokerwebsite.com/car-insurance.php">CAR INSURANCE</a></li>

              <li><a href="https://insurancebrokerwebsite.com/home-insurance.php">HOME INSURANCE</a></li>

              <li><a href="https://insurancebrokerwebsite.com/combined-insurance.php">COMBINED INSURANCE</a></li>

              <li><a href="https://insurancebrokerwebsite.com/blog.html">BLOG</a></li>

              <li><a href="https://insurancebrokerwebsite.com/contact.php">CONTACT US</a></li>

              <li><a class="highlighted" href="https://insurancebrokerwebsite.com/get-a-free-broker.php"><span style="color:#46556D">GET A FREE BROKER</span></a></li>

      </ul>

    </div>

  </nav><!--end nav-->



  <div class="free-quote-banner">

    <div class="row">

      <div class="col-md-8 col-md-offset-2">

            <h3 align="center">GET A FREE QUOTE</h3>

                <p align="center">Plan Ahead… Don’t Have Regrets</p><br><br><br>

            <p align="center" id="result">   <?php echo $result; ?></p>

      </div><!--col-md-6-->

    </div><!--end row-->

  </div><!--end free-quote-banner--><br>


<div align="center" class="insurance-companies">

    <div class="container">

      <div class="row">

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">

        </div>

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">
        </div>

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">

        </div>

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">

        </div>

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">

        </div>

        <div class="col-md-2 col-sm-4">

            <img alt="client-logo" class="img-responsive" src="images/client-logo.png">

        </div>

      </div><!--end row-->

    </div><!--end container-->

  </div><!--end insurance-companies-->


  <div class="get-quote-form"><br /><br /><br /><br />

        <p class="message-text" align="center">COMPLETE THIS SHORT FORM BELOW <br />AND WE WILL CONTACT YOU AS SOON AS POSSIBLE</p>

    <div class="row">

      <div class="col-md-4 col-md-offset-4" align="center"><br /><br />

          <p class="speedup-note">TO SPEED UP THE PROCESS…PLEASE COMPLETE THE SHORT FORM BELOW AND WE WILL CONTACT YOU AS SOON AS POSSIBLE<br /> <br />

            <a href="https://insurancebrokerwebsite.com/car-insurance-form.php">Car Insurance</a>&nbsp;|&nbsp;

            <a href="https://insurancebrokerwebsite.com/household-insurance-form.php">Household Insurance</a> |&nbsp;

            <a href="https://insurancebrokerwebsite.com/combined-insurance-form.php">Combined Insurance</a></p>

      </div><!--- /.col-md-->

    </div><!--- /.row--> <br /><br />

    <div class="row">

      <div class="col-md-8 col-md-offset-2 col-sm-12" align="center"> <br />


          <form method="post"><br />

            <div class="form-group center-block" align="center">

                <select align="center" name="insurance-option" required class="form-control" value="<?php echo $_POST['insurance-option']; ?>" />

                        <option disabled selected><strong> Insurance Option</strong></option>

                        <option>Car Insurance</option>

                        <option>Household/Home Insurance</option>

                        <option>Combined Insurance</option>

                </select>

            </div><!--end insurance options-->

            <div class="form-group center-block">

                    <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo $_POST['name']; ?>" />

                    

            </div><!--end name-->


            <div align="center" class="form-group center-block">

                    <input type="tel" name="phone" class="form-control" placeholder="Your Phone" value="<?php echo $_POST['phone']; ?>" />


            </div><!--end phone-->


            <div class="form-group center-block">

                    <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo $_POST['email']; ?>" />

            </div><!--end email-->


            <div class="form-group center-block">

                  <input type="text" class="form-control" id="idnumber" placeholder="ID Number" name="idnumber" value="<?php echo $_POST['idnumber']; ?>">

            </div><!--end ID number-->


            <div class="form-group center-block">


                <textarea class="form-control" id="message" name="message" placeholder="Comment"><?php echo $_POST['message']; ?> </textarea>

            </div><!--end Comment-->


                  <p align="center"> <input type="submit" name="submit" class="btn btn-default btn-lg quote-submit center-block" value="GET A QUOTE" ></p><br /><br /><br />

          </form>

        </div><!--- /.col-md--> 
        <br />

    </div><!--- .row--> 
    <br /><br /><br /><br />

  </div><!---/.get-quote-form-->


<div id="brokerinfo">

    <div class="row">
      
      <div class="col-md-6 col-sm-6 padding-0">

          <img alt="insurance-broker-profile-img" class="img-responsive" src="images/insurance-broker-profile-img.jpg">

      </div><!--end col-md-6-->


      <div class="col-md-6 col-sm-6 side-text">

          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus dignissim porttitor lectus eu sagittis.</p><br>

          <p>Maecenas aliquet, lorem nec aliquam pulvinar, justo mauris aliquet sapien, sit amet maximus odio lacus at ex. Etiam porttitor, metus eu pharetra euismod, massa nibh interdum odio, sit amet feugiat tortor massa non turpis.</p><br>

          <p>Read more about us <a href="https://insurancebrokerwebsite.com/about.html"><strong>here</strong></a>.</p>

      </div><!--end col-md-6-->

    </div><!--end row-->


    <div class="row rowtwo">

      <div class="col-md-6 col-sm-6 col-md-push-6 col-sm-push-6 padding-0">

          <img align="center" alt="insurance-side-img" class="img-responsive" src="images/insurance-side-img.jpg">

      </div><!--end of col-md-6-->


      <div class="col-md-6 col-sm-6 col-md-pull-6 col-sm-pull-6 side-text">

          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus dignissim porttitor lectus eu sagittis. Maecenas aliquet, lorem nec aliquam pulvinar, justo mauris aliquet sapien, sit amet maximus odio lacus at ex.</p><br>

          <p>Etiam porttitor, metus eu pharetra euismod, massa nibh interdum odio, sit amet feugiat tortor massa non turpis. In ac nulla nisl.</p><br>

          <p><a href="https://insurancebrokerwebsite.com/contact.php" rel="nofollow"><strong>Contact us</strong></a> for any questions you may have. We are here to help.</p>

      </div><!--- /.col-md-6-->

    </div><!--- /.row-->

  </div><!--- /.brokerinfo--><br /><br /><br />




<div class="testimonials">

    <h4 align="center">What Our Clients Say</h4>

    <section id="carousel">

      <div class="container">

        <div class="row">

          <div class="col-md-8 col-md-offset-2">

            <div class="quote">

            <div class="carousel slide" data-interval="3000" data-ride="carousel" id="fade-quote-carousel">


              <!-- Carousel indicators -->
              <ol class="carousel-indicators icon-controlers">
                <li data-slide-to="0" data-target="#fade-quote-carousel"></li>
                <li data-slide-to="1" data-target="#fade-quote-carousel"></li>
                <li data-slide-to="2" data-target="#fade-quote-carousel"></li>
              </ol>


              <!-- Carousel items -->
              <div class="carousel-inner quote-div">

                <div class="active item">

                    <blockquote>
                          <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rhoncus aliquam est, vitae tempus diam rhoncus in. In quis augue risus. Donec sapien odio, venenatis sit amet tempor non, fringilla sed erat. Maecenas accumsan a massa sit amet hendrerit. Aliquam pharetra, erat non sodales feugiat, quam turpis tempus nisl, blandit porta risus diam eget diam.”</p><br><br>

                            <span style="color:#9e9e9e">– Jason Brooks</span>
                    </blockquote>

                </div><!--- /.item-->


                <div class="item">

                  <blockquote>
                        <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rhoncus aliquam est, vitae tempus diam rhoncus in. In quis augue risus. Donec sapien odio, venenatis sit amet tempor non, fringilla sed erat. Maecenas accumsan a massa sit amet hendrerit.”<br><br>

                        <span style="color:#9e9e9e">- Will Jones</span></p>

                  </blockquote>

                </div><!--- /.item-->

                <div class="item">

                  <blockquote>
                        <p>“Interdum et malesuada fames ac ante ipsum primis in faucibus. Praesent dapibus, urna et porta posuere, massa felis consectetur arcu, sit amet sodales dui eros et ipsum. Mauris vitae pulvinar nunc, ac placerat nisl. Donec non cursus neque, vitae varius leo. Morbi vitae egestas neque. Cras ex urna, iaculis eleifend dolor vel, porttitor lacinia lacus.”<br><br>

                          <span style="color:#9e9e9e">- Michael Brown</span></p>

                  </blockquote>

                </div> <!--- /.item-->

              </div> <!--- /.quote-div-->
             </div> <!--- /.carousel slide-->
           </div> <!--- /.quote-->
          </div> <!--- /.col-md-->
        </div> <!--- /.row-->
      </div> <!--- /.container-->
    </section> <!--- /.carousel-->
  </div> <!--end of testimonials-->





  <div align="center" id="footer">

    <a href="https://insurancebrokerwebsite.com/about.html">ABOUT US</a>

    <a href="https://insurancebrokerwebsite.com/insurance-faq.html">FAQ</a> 

    <a href="https://insurancebrokerwebsite.com/insurance-resources.html">RESOURCES</a> 

    <a href="https://insurancebrokerwebsite.com/car-insurance.php">CAR INSURANCE</a> 

    <a href="https://insurancebrokerwebsite.com/home-insurance.php">HOME INSURANCE</a> 

    <a href="https://insurancebrokerwebsite.com/combined-insurance.php">COMBINED INSURANCE</a> 

    <a href="https://insurancebrokerwebsite.com/contact.php" rel="nofollow">CONTACT US</a>

  </div><!--end of footer-->


        <p align="center" class="trading"><br>Trading Hours: Mon-Thu (08:00-16:30), Fridays (08:00-16:00) &nbsp;|&nbsp; After Hours: +1-202-555-0168</p>


        <div align="center" class="social-links">

            <!--LINKED IN SOCIAL ICON-->
          <a href="https://www.linkedin.com/BROKERS-LINKED-IN-ACCOUNT/"><svg height="35" viewbox="0 0 24 24" width="35">
          <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" fill="#615F61"></path></svg></a> 

            <!--FACEBOOK SOCIAL ICON-->
          <a href="https://www.facebook.com/BROKERS-FACEBOOK-ACCOUNT/" target="_blank"><svg style="width:35px; height:35px" viewbox="0 0 24 24"><path d="M17,2V2H17V6H15C14.31,6 14,6.81 14,7.5V10H14L17,10V14H14V22H10V14H7V10H10V6A4,4 0 0,1 14,2H17Z" fill="#615F61"></path></svg></a>

      </div><!--end social-link-->


  <div align="center" class="policy-links">
    
    <a href="https://insurancebrokerwebsite.com/privacy-policy.html" rel="nofollow">Privacy Policy</a>

    <a href="https://insurancebrokerwebsite.com/terms-and-conditions.html" rel="nofollow">Terms &amp; Conditions</a>

  </div><!--end policy links-->

  <p align="center" class="text-muted copyright">&copy; InsuranceBroker.com 2017</p>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js">
  </script> 
  <!-- Include all compiled plugins (below), or include individual files as needed -->

   <script src="js/bootstrap.min.js">
  </script> 
  
   <!--FIXED NAVBAR SCRIPT-->
  <script>
  $('#topnavbar').affix({
     offset: {
         top: $('#banner').height()
     }   
  }); 
  </script>


</body>

</html>